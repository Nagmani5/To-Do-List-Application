// assets/script.js

function deleteTask(id) {
    if (confirm('Are you sure you want to delete this task?')) {
        window.location.href = 'delete_task.php?id=' + id;
    }
}

function updateTaskStatus(id) {
    // Implement the functionality to update task status (complete or incomplete) here
    console.log('Task status updated for task ID: ' + id);
}
