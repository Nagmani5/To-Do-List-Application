<?php
// Include tasks data
include_once('tasks.php');

// Display tasks
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style.css">
    <title>Simple To-Do List Application</title>
</head>
<body>
    <div class="mai-box">
    <h1>To-Do List Application</h1>

    <!-- Display tasks -->
    <ul id="task-list">
        <?php foreach ($tasks as $id => $task): ?>
          <center>
          <li>
                <input type="checkbox" <?php echo $task['completed'] ? 'checked' : ''; ?> onchange="updateTaskStatus(<?php echo $id; ?>)">
                <?php echo $task['name']; ?>
                <button onclick="deleteTask(<?php echo $id; ?>)">Delete</button>
            </li>
        </center>
        <?php endforeach; ?>
    </ul>

    <!-- Add Task Form -->
    <form action="add_task.php" method="POST">
      
        <input type="text" id="taskName" name="taskName" Placeholder="Add Task" required>
        <button type="submit">Add Task</button>
    </form>
        </div>

    <script src="assets/script.js"></script>
</body>
</html>
