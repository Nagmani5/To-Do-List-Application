<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newTaskName = $_POST['taskName'];

    // Basic validation
    if (!empty($newTaskName)) {
        // Include tasks data
        include_once('tasks.php');

        // Add new task
        $tasks[] = ['name' => $newTaskName, 'completed' => false];

        // Save tasks data
        file_put_contents('tasks.php', '<?php $tasks = ' . var_export($tasks, true) . ';');
    }
}

// Redirect back to the main page
header('Location: index.php');
exit;
