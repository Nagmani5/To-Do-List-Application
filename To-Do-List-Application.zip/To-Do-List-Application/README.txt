# Simple To-Do List Application

## Setup
1. Clone the repository.
2. Open the project in a web server environment (e.g., XAMPP, MAMP).
3. Paste  DO TO LIST Application inside the hddoc
3. Access the application through the web browser.

## Features
- Add tasks with a name.
- View tasks with completion status.
- Delete tasks individually.
- Mark tasks as complete or incomplete.

## Code Organization
- `index.php`: Main page displaying tasks.
- `add_task.php`: Adds new tasks.
- `delete_task.php`: Deletes tasks.
- `assets/style.css`: Basic styling.
- `assets/script.js`: Basic JavaScript for interactions.
- `tasks.php`: Data storage for tasks.

