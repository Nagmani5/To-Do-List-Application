<?php

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $taskId = $_GET['id'];

    // Include tasks data
    include_once('tasks.php');

    // Delete task
    unset($tasks[$taskId]);

    // Save tasks data
    file_put_contents('tasks.php', '<?php $tasks = ' . var_export($tasks, true) . ';');
}

// Redirect back to the main page
header('Location: index.php');
exit;
