<?php $tasks = array (
  3 => 
  array (
    'name' => 'task 1',
    'completed' => false,
  ),
);